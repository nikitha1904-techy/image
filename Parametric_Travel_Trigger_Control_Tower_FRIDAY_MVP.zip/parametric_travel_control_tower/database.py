import json,sqlite3
from pathlib import Path
from config import settings
SCHEMA="""
CREATE TABLE IF NOT EXISTS source_observations(id INTEGER PRIMARY KEY AUTOINCREMENT,event_key TEXT,source_name TEXT,source_role TEXT,flight_number TEXT,flight_date TEXT,status TEXT,delay_minutes REAL,quality_score REAL,fetched_at TEXT,payload_json TEXT);
CREATE TABLE IF NOT EXISTS canonical_events(event_id TEXT PRIMARY KEY,flight_number TEXT,flight_date TEXT,selected_source TEXT,status TEXT,delay_minutes REAL,confidence REAL,conflict INTEGER,generated_at TEXT,payload_json TEXT);
CREATE TABLE IF NOT EXISTS trigger_decisions(decision_id TEXT PRIMARY KEY,event_id TEXT,rule_version TEXT,trigger_type TEXT,qualified INTEGER,payout_amount REAL,decision_status TEXT,confidence REAL,decided_at TEXT,payload_json TEXT);
CREATE TABLE IF NOT EXISTS audit_log(id INTEGER PRIMARY KEY AUTOINCREMENT,record_type TEXT,record_id TEXT,created_at TEXT,snapshot_json TEXT);
"""
def connect(path=None):
    p=Path(path or settings.database_path); p.parent.mkdir(parents=True,exist_ok=True); c=sqlite3.connect(p); c.executescript(SCHEMA); return c
def save_observation(o,path=None):
    with connect(path) as c:c.execute('INSERT INTO source_observations(event_key,source_name,source_role,flight_number,flight_date,status,delay_minutes,quality_score,fetched_at,payload_json) VALUES(?,?,?,?,?,?,?,?,?,?)',(f'{o.flight_number}:{o.flight_date}',o.source_name,o.source_role,o.flight_number,o.flight_date,o.status,o.delay_minutes,o.quality_score,o.fetched_at,json.dumps(o.to_dict(),default=str)))
def save_event(e,path=None):
    with connect(path) as c:
        c.execute('INSERT OR REPLACE INTO canonical_events VALUES(?,?,?,?,?,?,?,?,?,?)',(e.event_id,e.flight_number,e.flight_date,e.selected_source,e.status,e.delay_minutes,e.confidence,int(e.conflict),e.generated_at,json.dumps(e.to_dict(),default=str)))
        c.execute('INSERT INTO audit_log(record_type,record_id,created_at,snapshot_json) VALUES(?,?,?,?)',('canonical_event',e.event_id,e.generated_at,json.dumps(e.to_dict(),default=str)))
def save_decision(d,path=None):
    with connect(path) as c:
        c.execute('INSERT OR REPLACE INTO trigger_decisions VALUES(?,?,?,?,?,?,?,?,?,?)',(d.decision_id,d.event_id,d.rule_version,d.trigger_type,int(d.qualified),d.payout_amount,d.decision_status,d.confidence,d.decided_at,json.dumps(d.to_dict(),default=str)))
        c.execute('INSERT INTO audit_log(record_type,record_id,created_at,snapshot_json) VALUES(?,?,?,?)',('trigger_decision',d.decision_id,d.decided_at,json.dumps(d.to_dict(),default=str)))
