import requests
from config import settings
from models import FlightObservation
class AeroDataBoxProvider:
    name='AeroDataBox';role='secondary'
    @property
    def configured(self):return bool(settings.aerodatabox_api_key)
    def fetch(self,q):
        if not self.configured:return FlightObservation(self.name,self.role,q.flight_number,q.flight_date,error='API key not configured')
        host=settings.aerodatabox_api_host;url=f"https://{host}/flights/number/{q.flight_number.replace(' ','').upper()}/{q.flight_date}"
        r=requests.get(url,headers={'X-RapidAPI-Key':settings.aerodatabox_api_key,'X-RapidAPI-Host':host},params={'withLocation':'false','withAircraftImage':'false'},timeout=settings.http_timeout_seconds);r.raise_for_status();data=r.json();rows=data if isinstance(data,list) else data.get('flights',[])
        if not rows:return FlightObservation(self.name,self.role,q.flight_number,q.flight_date,raw_payload=data,error='No flight returned')
        f=rows[0];dep=f.get('departure',{});arr=f.get('arrival',{})
        def tm(side,key):
            o=side.get(key) or {};return o.get('utc') or o.get('local')
        status=(f.get('status') or '').upper()
        return FlightObservation(self.name,self.role,q.flight_number,q.flight_date,origin=(dep.get('airport') or {}).get('iata'),destination=(arr.get('airport') or {}).get('iata'),scheduled_departure=tm(dep,'scheduledTime'),estimated_departure=tm(dep,'revisedTime'),actual_departure=tm(dep,'actualTime'),scheduled_arrival=tm(arr,'scheduledTime'),estimated_arrival=tm(arr,'revisedTime'),actual_arrival=tm(arr,'actualTime'),status=status,cancelled='CANCEL' in status,diverted='DIVERT' in status,departure_gate=dep.get('gate'),arrival_gate=arr.get('gate'),departure_terminal=dep.get('terminal'),arrival_terminal=arr.get('terminal'),raw_payload=data)
