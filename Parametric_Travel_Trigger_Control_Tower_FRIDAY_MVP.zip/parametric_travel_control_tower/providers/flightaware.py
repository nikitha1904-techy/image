import requests
from config import settings
from models import FlightObservation
class FlightAwareProvider:
    name='FlightAware AeroAPI'; role='secondary'
    @property
    def configured(self):return bool(settings.flightaware_api_key)
    def fetch(self,q):
        if not self.configured:return FlightObservation(self.name,self.role,q.flight_number,q.flight_date,error='API key not configured')
        url=f"https://aeroapi.flightaware.com/aeroapi/flights/{q.flight_number.replace(' ','').upper()}"
        r=requests.get(url,headers={'x-apikey':settings.flightaware_api_key},params={'start':q.flight_date,'end':q.flight_date,'max_pages':1},timeout=settings.http_timeout_seconds);r.raise_for_status();data=r.json();rows=data.get('flights') or []
        if not rows:return FlightObservation(self.name,self.role,q.flight_number,q.flight_date,raw_payload=data,error='No flight returned')
        f=rows[0]
        return FlightObservation(self.name,self.role,q.flight_number,q.flight_date,origin=(f.get('origin') or {}).get('code'),destination=(f.get('destination') or {}).get('code'),scheduled_departure=f.get('scheduled_out'),estimated_departure=f.get('estimated_out'),actual_departure=f.get('actual_out'),scheduled_arrival=f.get('scheduled_in'),estimated_arrival=f.get('estimated_in'),actual_arrival=f.get('actual_in'),status=f.get('status'),cancelled=bool(f.get('cancelled')),diverted=bool(f.get('diverted')),departure_gate=f.get('gate_origin'),arrival_gate=f.get('gate_destination'),departure_terminal=f.get('terminal_origin'),arrival_terminal=f.get('terminal_destination'),tail_number=f.get('registration'),raw_payload=data)
