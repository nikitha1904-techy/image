import requests,xml.etree.ElementTree as ET
from datetime import datetime
from config import settings
from models import CorroborationEvidence
class FAANASProvider:
    name='FAA NAS Status';role='public_corroboration'
    def fetch(self,origin=None,destination=None):
        r=requests.get('https://nasstatus.faa.gov/api/airport-status-information',timeout=settings.http_timeout_seconds);r.raise_for_status();airports={x for x in [origin,destination] if x};out=[]
        try:
            root=ET.fromstring(r.text)
            for e in root.iter():
                raw=' '.join(''.join(e.itertext()).split())
                if any(a in raw for a in airports):out.append(CorroborationEvidence(self.name,next((a for a in airports if a in raw),None),e.tag.split('}')[-1],raw[:700],datetime.utcnow().isoformat()+'Z',{'xml_excerpt':raw[:1200]}))
        except ET.ParseError:pass
        return out[:20]
