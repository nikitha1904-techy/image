from datetime import datetime,timedelta,timezone
from models import FlightObservation
def iso(d):return d.astimezone(timezone.utc).isoformat().replace('+00:00','Z')
class DemoPrimary:
    name='Demo Commercial Primary';role='primary';configured=True
    def fetch(self,q):
        base=datetime.fromisoformat(q.flight_date+'T15:00:00+00:00');status='CANCELLED' if q.flight_number.upper()=='DEMO2' else ('ON_TIME' if q.flight_number.upper()=='DEMO3' else 'LANDED');delay=3 if status=='ON_TIME' else 205
        return FlightObservation(self.name,self.role,q.flight_number,q.flight_date,origin=q.origin or 'DFW',destination=q.destination or 'JFK',scheduled_departure=iso(base),actual_departure=None if status=='CANCELLED' else iso(base+timedelta(minutes=delay)),scheduled_arrival=iso(base+timedelta(hours=3)),actual_arrival=None if status=='CANCELLED' else iso(base+timedelta(hours=3,minutes=delay)),status=status,cancelled=status=='CANCELLED',provider_updated_at=datetime.utcnow().isoformat()+'Z',raw_payload={'demo':True})
class DemoSecondary(DemoPrimary):
    name='Demo Commercial Secondary';role='secondary'
    def fetch(self,q):
        o=super().fetch(q)
        if not o.cancelled and q.flight_number.upper()!='DEMO3':
            base=datetime.fromisoformat(q.flight_date+'T15:00:00+00:00');o.actual_departure=iso(base+timedelta(minutes=198));o.actual_arrival=iso(base+timedelta(hours=3,minutes=198))
        return o
