import re,requests
from config import settings
from models import FlightObservation
class CiriumProvider:
    name='Cirium / FlightStats'; role='primary'
    @property
    def configured(self): return bool(settings.cirium_app_id and settings.cirium_app_key)
    def fetch(self,q):
        if not self.configured:return FlightObservation(self.name,self.role,q.flight_number,q.flight_date,error='API credentials not configured')
        m=re.match(r'([A-Za-z]{2,3})(\d+)',q.flight_number.replace(' ',''))
        if not m:return FlightObservation(self.name,self.role,q.flight_number,q.flight_date,error='Use airline code + flight number, e.g. AA100')
        carrier,num=m.group(1).upper(),m.group(2); y,mo,d=[int(x) for x in q.flight_date.split('-')]
        url=f'https://api.flightstats.com/flex/flightstatus/rest/v2/json/flight/status/{carrier}/{num}/dep/{y}/{mo}/{d}'
        r=requests.get(url,params={'appId':settings.cirium_app_id,'appKey':settings.cirium_app_key,'utc':'true'},timeout=settings.http_timeout_seconds);r.raise_for_status();data=r.json(); rows=data.get('flightStatuses') or []
        if not rows:return FlightObservation(self.name,self.role,q.flight_number,q.flight_date,raw_payload=data,error='No flight returned')
        f=rows[0];ops=f.get('operationalTimes',{}); ar=f.get('airportResources',{})
        g=lambda k:(ops.get(k) or {}).get('dateUtc')
        return FlightObservation(self.name,self.role,f"{f.get('carrierFsCode',carrier)}{f.get('flightNumber',num)}",q.flight_date,origin=f.get('departureAirportFsCode'),destination=f.get('arrivalAirportFsCode'),scheduled_departure=g('scheduledGateDeparture'),estimated_departure=g('estimatedGateDeparture'),actual_departure=g('actualGateDeparture'),scheduled_arrival=g('scheduledGateArrival'),estimated_arrival=g('estimatedGateArrival'),actual_arrival=g('actualGateArrival'),status=f.get('status'),cancelled=f.get('status')=='C',diverted=f.get('status')=='D',departure_gate=ar.get('departureGate'),arrival_gate=ar.get('arrivalGate'),departure_terminal=ar.get('departureTerminal'),arrival_terminal=ar.get('arrivalTerminal'),raw_payload=data)
