import os
from dataclasses import dataclass
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

def b(name, default=False): return os.getenv(name,str(default)).lower() in {'1','true','yes','on'}
@dataclass(frozen=True)
class Settings:
    cirium_app_id:str=os.getenv('CIRIUM_APP_ID','')
    cirium_app_key:str=os.getenv('CIRIUM_APP_KEY','')
    flightaware_api_key:str=os.getenv('FLIGHTAWARE_API_KEY','')
    aerodatabox_api_key:str=os.getenv('AERODATABOX_API_KEY','')
    aerodatabox_api_host:str=os.getenv('AERODATABOX_API_HOST','aerodatabox.p.rapidapi.com')
    database_path:str=os.getenv('DATABASE_PATH','data/parametric_travel.db')
    http_timeout_seconds:int=int(os.getenv('HTTP_TIMEOUT_SECONDS','20'))
    enable_demo_mode:bool=b('ENABLE_DEMO_MODE',True)
    default_delay_threshold_minutes:int=int(os.getenv('DEFAULT_DELAY_THRESHOLD_MINUTES','180'))
    default_delay_payout:float=float(os.getenv('DEFAULT_DELAY_PAYOUT','100'))
    auto_approve_confidence:float=float(os.getenv('AUTO_APPROVE_CONFIDENCE','0.85'))
    manual_review_confidence:float=float(os.getenv('MANUAL_REVIEW_CONFIDENCE','0.65'))
settings=Settings()
