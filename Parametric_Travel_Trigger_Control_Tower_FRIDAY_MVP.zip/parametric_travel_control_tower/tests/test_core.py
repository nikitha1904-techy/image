import unittest
from models import FlightObservation,CanonicalFlightEvent,FlightQuery
from services.normalization import enrich
from services.quality import score
from services.reconciliation import reconcile
from services.trigger_engine import decide
from services.orchestrator import ParametricTravelControlTower
class CoreTests(unittest.TestCase):
 def test_delay(self):
  o=FlightObservation('x','primary','AA1','2026-08-14',scheduled_arrival='2026-08-14T10:00:00Z',actual_arrival='2026-08-14T13:05:00Z',status='landed');self.assertEqual(enrich(o).delay_minutes,185)
 def test_quality(self):
  o=FlightObservation('x','primary','AA1','2026-08-14',origin='DFW',destination='JFK',scheduled_departure='2026-08-14T10:00:00Z',scheduled_arrival='2026-08-14T13:00:00Z',status='LANDED');self.assertGreater(score(o).quality_score,.5)
 def test_reconcile_primary(self):
  a=FlightObservation('P','primary','AA1','2026-08-14',origin='DFW',destination='JFK',scheduled_arrival='2026-08-14T10:00:00Z',actual_arrival='2026-08-14T13:05:00Z',status='landed');b=FlightObservation('S','secondary','AA1','2026-08-14',origin='DFW',destination='JFK',scheduled_arrival='2026-08-14T10:00:00Z',actual_arrival='2026-08-14T13:00:00Z',status='landed');e=reconcile([a,b],[]);self.assertEqual(e.selected_source,'P');self.assertFalse(e.conflict)
 def test_delay_trigger(self):
  e=CanonicalFlightEvent('e','AA1','2026-08-14','DFW','JFK','LANDED',None,None,None,None,185,'P','primary',.95,.95,False,[],[],['P'],'now');self.assertTrue(decide(e,180,100).qualified)
 def test_cancel_trigger(self):
  e=CanonicalFlightEvent('e','AA1','2026-08-14','DFW','JFK','CANCELLED',None,None,None,None,None,'P','primary',.95,.95,False,[],[],['P'],'now');self.assertTrue(decide(e).qualified)
 def test_conflict_manual(self):
  a=FlightObservation('P','primary','AA1','2026-08-14',origin='DFW',destination='JFK',scheduled_arrival='2026-08-14T10:00:00Z',actual_arrival='2026-08-14T13:05:00Z',status='landed');b=FlightObservation('S','secondary','AA1','2026-08-14',origin='DFW',destination='JFK',scheduled_arrival='2026-08-14T10:00:00Z',status='cancelled',cancelled=True);e=reconcile([a,b],[]);self.assertTrue(e.conflict);self.assertTrue(decide(e).manual_review_required)
 def test_demo_end_to_end(self):
  import tempfile,os
  p=tempfile.mktemp(suffix='.db');r=ParametricTravelControlTower(p).run(FlightQuery('DEMO1','2026-08-14','DFW','JFK'));self.assertTrue(r['decision'].qualified);self.assertEqual(len(r['observations']),2);self.assertTrue(os.path.exists(p))
if __name__=='__main__':unittest.main()
