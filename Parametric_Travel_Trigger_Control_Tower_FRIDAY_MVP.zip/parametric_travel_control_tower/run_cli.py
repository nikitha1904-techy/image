from models import FlightQuery
from services.orchestrator import ParametricTravelControlTower
r=ParametricTravelControlTower().run(FlightQuery('DEMO1','2026-08-14','DFW','JFK'));print(r['event'].to_dict());print(r['decision'].to_dict());print(r['audit_path'])
