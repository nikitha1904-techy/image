import json
from pathlib import Path
from datetime import datetime
def export_audit_pack(e,d,obs,corr,out_dir='audit_exports'):
    Path(out_dir).mkdir(parents=True,exist_ok=True);p=Path(out_dir)/f'{d.decision_id}_audit_pack.json';payload={'exported_at':datetime.utcnow().isoformat()+'Z','canonical_event':e.to_dict(),'trigger_decision':d.to_dict(),'source_observations':[o.to_dict() for o in obs],'corroboration':[x.__dict__ for x in corr],'governance':{'decision_method':'deterministic rules','ai_used_for_trigger':False,'raw_evidence_retained':True,'manual_review_on_conflict':True}};p.write_text(json.dumps(payload,indent=2,default=str));return str(p)
