import uuid
from datetime import datetime
from config import settings
from models import TriggerDecision
RULE_VERSION='DELAY_CANCEL_MVP_v1.0'
def decide(e,threshold=None,payout=None):
    threshold=threshold or settings.default_delay_threshold_minutes;payout=float(settings.default_delay_payout if payout is None else payout)
    if e.conflict or e.confidence<settings.manual_review_confidence:q=False;s='MANUAL_REVIEW';m=True;r='Evidence conflict or confidence below manual-review threshold.'
    elif e.status=='CANCELLED':q=True;s='AUTO_APPROVED' if e.confidence>=settings.auto_approve_confidence else 'MANUAL_REVIEW';m=s!='AUTO_APPROVED';r='Flight cancellation validated by evidence engine.'
    elif e.delay_minutes is not None and e.delay_minutes>=threshold:q=True;s='AUTO_APPROVED' if e.confidence>=settings.auto_approve_confidence else 'MANUAL_REVIEW';m=s!='AUTO_APPROVED';r=f'Validated delay {e.delay_minutes:.0f} min meets threshold {threshold} min.'
    else:q=False;s='NO_TRIGGER';m=False;r='Objective delay/cancellation trigger not met.'
    return TriggerDecision('DEC-'+uuid.uuid4().hex[:10].upper(),e.event_id,RULE_VERSION,'FLIGHT_DELAY_OR_CANCELLATION',threshold,e.delay_minutes,q,payout if q else 0,s,r,e.confidence,m,datetime.utcnow().isoformat()+'Z')
