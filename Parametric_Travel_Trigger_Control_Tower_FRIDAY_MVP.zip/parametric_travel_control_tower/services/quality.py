from datetime import datetime,timezone
from .normalization import parse_dt
FIELDS=['flight_number','origin','destination','scheduled_departure','scheduled_arrival','status'];REL={'primary':1.0,'secondary':.85}
def score(o):
    o.completeness=round(sum(bool(getattr(o,f,None)) for f in FIELDS)/len(FIELDS),3);stamp=parse_dt(o.provider_updated_at) or parse_dt(o.fetched_at)
    if stamp:
        age=max(0,(datetime.now(timezone.utc)-stamp.astimezone(timezone.utc)).total_seconds());o.freshness=max(0,1-min(age/3600,1))
    else:o.freshness=.5
    o.reliability=REL.get(o.source_role,.5);o.quality_score=round(.45*o.completeness+.25*o.freshness+.30*o.reliability,3);return o
