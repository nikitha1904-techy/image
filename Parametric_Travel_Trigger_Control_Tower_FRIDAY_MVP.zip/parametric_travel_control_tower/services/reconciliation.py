import uuid
from datetime import datetime
from models import CanonicalFlightEvent
from .normalization import enrich
from .quality import score
def reconcile(observations,corroboration):
    u=[score(enrich(o)) for o in observations if not o.error]
    if not u:raise ValueError('No usable commercial flight observations')
    u.sort(key=lambda x:(x.source_role=='primary',x.quality_score),reverse=True);s=u[0];statuses=[o.status for o in u];delays=[o.delay_minutes for o in u if o.delay_minutes is not None];reasons=[]
    if len(set(statuses))>1:reasons.append('Commercial sources disagree on normalized status')
    if len(delays)>=2 and max(delays)-min(delays)>15:reasons.append(f'Commercial delay estimates differ by {max(delays)-min(delays):.1f} minutes')
    agreement=1.0
    if len(u)>1:
        sa=sum(o.status==s.status for o in u)/len(u);da=1.0 if not delays or s.delay_minutes is None else sum(abs(d-s.delay_minutes)<=15 for d in delays)/len(delays);agreement=.6*sa+.4*da
    conf=max(0,min(1,.55*s.quality_score+.35*agreement+.10*(1 if corroboration else .5)))
    return CanonicalFlightEvent('EVT-'+uuid.uuid4().hex[:10].upper(),s.flight_number,s.flight_date,s.origin,s.destination,s.status,s.scheduled_departure,s.actual_departure or s.estimated_departure,s.scheduled_arrival,s.actual_arrival or s.estimated_arrival,s.delay_minutes,s.source_name,s.source_role,round(conf,3),round(agreement,3),bool(reasons),reasons,[e.__dict__ for e in corroboration],[o.source_name for o in u]+list(dict.fromkeys(e.source_name for e in corroboration)),datetime.utcnow().isoformat()+'Z')
