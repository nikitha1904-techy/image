from concurrent.futures import ThreadPoolExecutor,as_completed
from config import settings
from providers.cirium import CiriumProvider
from providers.flightaware import FlightAwareProvider
from providers.aerodatabox import AeroDataBoxProvider
from providers.faa_nas import FAANASProvider
from providers.demo import DemoPrimary,DemoSecondary
from database import save_observation,save_event,save_decision
from .normalization import enrich
from .quality import score
from .reconciliation import reconcile
from .trigger_engine import decide
from .audit import export_audit_pack
class ParametricTravelControlTower:
    def __init__(self,db_path=None):self.db_path=db_path
    def providers(self,q):
        if settings.enable_demo_mode and q.flight_number.upper().startswith('DEMO'):return [DemoPrimary(),DemoSecondary()]
        return [p for p in [CiriumProvider(),FlightAwareProvider(),AeroDataBoxProvider()] if p.configured]
    def run(self,q,threshold=None,payout=None,include_faa=True):
        ps=self.providers(q)
        if not ps:raise RuntimeError('No commercial provider credentials configured. Add a key or use DEMO1/DEMO2/DEMO3.')
        obs=[]
        with ThreadPoolExecutor(max_workers=len(ps)) as ex:
            fs={ex.submit(p.fetch,q):p for p in ps}
            for f in as_completed(fs):
                try:o=f.result()
                except Exception as x:
                    from models import FlightObservation;p=fs[f];o=FlightObservation(p.name,p.role,q.flight_number,q.flight_date,error=str(x))
                if not o.error:score(enrich(o))
                obs.append(o);save_observation(o,self.db_path)
        usable=[o for o in obs if not o.error]
        if not usable:raise RuntimeError('All configured providers failed: '+' | '.join(f'{o.source_name}: {o.error}' for o in obs))
        origin=q.origin or next((o.origin for o in usable if o.origin),None);dest=q.destination or next((o.destination for o in usable if o.destination),None);corr=[]
        if include_faa and not q.flight_number.upper().startswith('DEMO'):
            try:corr=FAANASProvider().fetch(origin,dest)
            except Exception:pass
        e=reconcile(obs,corr);d=decide(e,threshold,payout);save_event(e,self.db_path);save_decision(d,self.db_path);a=export_audit_pack(e,d,obs,corr);return {'observations':obs,'corroboration':corr,'event':e,'decision':d,'audit_path':a}
