from datetime import datetime
def parse_dt(v):
    if not v:return None
    try:return datetime.fromisoformat(str(v).replace('Z','+00:00'))
    except:return None
def normalized_status(o):
    s=(o.status or '').upper()
    if o.cancelled or 'CANCEL' in s or s=='C':return 'CANCELLED'
    if o.diverted or 'DIVERT' in s or s=='D':return 'DIVERTED'
    if 'LAND' in s or 'ARRIV' in s:return 'LANDED'
    if 'AIR' in s or 'EN ROUTE' in s or 'ACTIVE' in s:return 'IN_AIR'
    if 'DELAY' in s:return 'DELAYED'
    if 'SCHED' in s or 'FILED' in s:return 'SCHEDULED'
    if 'ON TIME' in s or 'ON_TIME' in s:return 'ON_TIME'
    return s or 'UNKNOWN'
def calculate_delay(o):
    sched=parse_dt(o.scheduled_arrival) or parse_dt(o.scheduled_departure);actual=parse_dt(o.actual_arrival) or parse_dt(o.estimated_arrival) or parse_dt(o.actual_departure) or parse_dt(o.estimated_departure)
    return round((actual-sched).total_seconds()/60,1) if sched and actual else None
def enrich(o):o.status=normalized_status(o);o.delay_minutes=calculate_delay(o);return o
