import re
def normalize_flight_number(v):return re.sub(r'\s+','',v or '').upper()
def identity_match(a,b):
    if normalize_flight_number(a.flight_number)==normalize_flight_number(b.flight_number):return True
    return bool(a.flight_date==b.flight_date and a.origin==b.origin and a.destination==b.destination and set(a.codeshares)&set(b.codeshares))
