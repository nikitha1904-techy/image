import streamlit as st,pandas as pd
from datetime import date
from models import FlightQuery
from services.orchestrator import ParametricTravelControlTower
from config import settings
st.set_page_config(page_title='Parametric Travel Trigger Control Tower',layout='wide')
st.title('Parametric Travel Insurance — Trigger Validation Control Tower')
st.caption('Friday MVP: Flight Delay + Cancellation | multi-source evidence reconciliation | deterministic settlement | audit-ready')
with st.sidebar:
 st.header('Policy Rule');threshold=st.number_input('Delay threshold (minutes)',15,720,settings.default_delay_threshold_minutes,15);payout=st.number_input('Prototype payout ($)',0.0,value=float(settings.default_delay_payout),step=25.0);st.info('Objective trigger decisions are deterministic. AI is not used for payout qualification.')
c1,c2,c3,c4=st.columns(4);flight=c1.text_input('Flight number','DEMO1').upper().strip();fdate=str(c2.date_input('Flight date',date.today()));origin=c3.text_input('Origin (optional)','').upper().strip() or None;dest=c4.text_input('Destination (optional)','').upper().strip() or None
if st.button('Validate Trigger',type='primary',use_container_width=True):
 try:
  with st.spinner('Ingesting and reconciling evidence...'):r=ParametricTravelControlTower().run(FlightQuery(flight,fdate,origin,dest),int(threshold),float(payout))
  e,d=r['event'],r['decision'];st.subheader('1. Canonical Flight Event');a,b,c,dd,ee=st.columns(5);a.metric('Status',e.status);b.metric('Validated delay','N/A' if e.delay_minutes is None else f'{e.delay_minutes:.0f} min');c.metric('Confidence',f'{e.confidence:.0%}');dd.metric('Agreement',f'{e.agreement_score:.0%}');ee.metric('Selected source',e.selected_source)
  if e.conflict:st.warning('Source conflict: '+'; '.join(e.conflict_reasons))
  st.subheader('2. Multi-source Evidence');rows=[{'Source':o.source_name,'Role':o.source_role,'Status':o.status or 'ERROR','Origin':o.origin,'Destination':o.destination,'Delay min':o.delay_minutes,'Completeness':f'{o.completeness:.0%}','Freshness':f'{o.freshness:.0%}','Reliability':f'{o.reliability:.0%}','Quality':f'{o.quality_score:.0%}','Error':o.error} for o in r['observations']];st.dataframe(pd.DataFrame(rows),use_container_width=True,hide_index=True)
  st.subheader('3. FAA NAS Public Corroboration')
  if r['corroboration']:st.dataframe(pd.DataFrame([{'Source':x.source_name,'Airport':x.airport,'Event':x.event_type,'Description':x.description} for x in r['corroboration']]),use_container_width=True,hide_index=True)
  else:st.caption('No matching FAA NAS disruption evidence returned (or demo mode).')
  st.subheader('4. Deterministic Trigger Decision');x,y,z,w=st.columns(4);x.metric('Decision',d.decision_status);y.metric('Qualified','YES' if d.qualified else 'NO');z.metric('Payout',f'${d.payout_amount:,.0f}');w.metric('Rule',d.rule_version);st.write(d.reason)
  if d.manual_review_required:st.error('Automatic settlement paused — manual review required.')
  elif d.qualified:st.success('Objective trigger validated — prototype auto-approval.')
  else:st.info('Trigger not met.')
  st.subheader('5. Governance & Audit');st.code(f'Event ID: {e.event_id}\nDecision ID: {d.decision_id}\nEvidence snapshot: {r["audit_path"]}\nRaw observations: SQLite\nAI trigger decision: NO\nManual review on ambiguity: YES')
  with st.expander('Canonical event JSON'):st.json(e.to_dict())
 except Exception as ex:st.error(str(ex))
st.divider();st.caption('Source roles from design: Cirium = primary; FlightAware/AeroDataBox = secondary; FAA NAS = public corroboration; BTS/TranStats = historical/post-event audit. Future: OAG, PNR/MCT/reaccommodation, SITA/WorldTracer.')
