import compileall,subprocess,sys
if not compileall.compile_dir('.',quiet=1):raise SystemExit('Compilation failed')
raise SystemExit(subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v']).returncode)
