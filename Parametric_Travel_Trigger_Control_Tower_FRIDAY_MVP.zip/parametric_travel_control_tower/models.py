from dataclasses import dataclass, field, asdict
from datetime import datetime
from typing import Any, Optional
@dataclass
class FlightQuery:
    flight_number:str; flight_date:str; origin:Optional[str]=None; destination:Optional[str]=None
@dataclass
class FlightObservation:
    source_name:str; source_role:str; flight_number:str; flight_date:str
    marketing_carrier:Optional[str]=None; operating_carrier:Optional[str]=None; origin:Optional[str]=None; destination:Optional[str]=None
    scheduled_departure:Optional[str]=None; estimated_departure:Optional[str]=None; actual_departure:Optional[str]=None
    scheduled_arrival:Optional[str]=None; estimated_arrival:Optional[str]=None; actual_arrival:Optional[str]=None
    status:Optional[str]=None; cancelled:bool=False; diverted:bool=False
    departure_gate:Optional[str]=None; arrival_gate:Optional[str]=None; departure_terminal:Optional[str]=None; arrival_terminal:Optional[str]=None
    tail_number:Optional[str]=None; codeshares:list[str]=field(default_factory=list); provider_updated_at:Optional[str]=None
    fetched_at:str=field(default_factory=lambda:datetime.utcnow().isoformat()+'Z'); raw_payload:dict[str,Any]=field(default_factory=dict)
    completeness:float=0.0; freshness:float=0.0; reliability:float=0.0; quality_score:float=0.0; delay_minutes:Optional[float]=None; error:Optional[str]=None
    def to_dict(self): return asdict(self)
@dataclass
class CorroborationEvidence:
    source_name:str; airport:Optional[str]; event_type:str; description:str; fetched_at:str; raw_payload:dict[str,Any]=field(default_factory=dict)
@dataclass
class CanonicalFlightEvent:
    event_id:str; flight_number:str; flight_date:str; origin:Optional[str]; destination:Optional[str]; status:str
    scheduled_departure:Optional[str]; actual_or_estimated_departure:Optional[str]; scheduled_arrival:Optional[str]; actual_or_estimated_arrival:Optional[str]
    delay_minutes:Optional[float]; selected_source:str; selected_source_role:str; confidence:float; agreement_score:float; conflict:bool
    conflict_reasons:list[str]; corroboration:list[dict]; evidence_sources:list[str]; generated_at:str
    def to_dict(self): return asdict(self)
@dataclass
class TriggerDecision:
    decision_id:str; event_id:str; rule_version:str; trigger_type:str; threshold_minutes:int; observed_delay_minutes:Optional[float]
    qualified:bool; payout_amount:float; decision_status:str; reason:str; confidence:float; manual_review_required:bool; decided_at:str
    def to_dict(self): return asdict(self)
