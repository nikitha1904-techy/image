# Mapping to supplied architecture
1. Event ingestion layer — implemented.
2. Flight identity & itinerary resolver — flight identity implemented; PNR/itinerary partner integration reserved for next phase.
3. Evidence reconciliation engine — implemented with source priority, freshness, confidence and conflicts.
4. Trigger & payout engine — deterministic delay/cancel rules implemented.
5. Governance & audit — evidence snapshots, rules, IDs, manual review implemented.

Recommended MVP stack represented exactly: Primary Cirium; Secondary FlightAware/AeroDataBox; Public FAA NAS; BTS post-event audit. OAG can replace Cirium when licensed. Missed connection and baggage are intentionally deferred because the supplied document requires PNR/MCT/reaccommodation and SITA/WorldTracer/airline bag-event access.
