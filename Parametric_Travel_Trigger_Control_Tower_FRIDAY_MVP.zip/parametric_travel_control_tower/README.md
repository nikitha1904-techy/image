# Parametric Travel Insurance — Trigger Validation Control Tower

Friday MVP implementing the manager document's **Flight Delay + Cancellation** architecture.

## Implemented layers
- Event ingestion: Cirium/FlightStats primary; FlightAware + AeroDataBox secondary; FAA NAS public corroboration.
- Flight identity normalization/resolver.
- Evidence reconciliation: source role priority, completeness, freshness, reliability, agreement/conflict rules, confidence.
- Deterministic trigger + payout decision; AI is deliberately not used for the objective trigger.
- Governance/audit: raw observations in SQLite, canonical event, decision, rule version, JSON audit pack, manual review on conflict.

BTS/TranStats is documented as historical/calibration/post-event audit, not a real-time settlement feed. OAG, airline/PNR/MCT/reaccommodation and SITA/WorldTracer are future partner/commercial layers and are not faked as public APIs.

## Run
1. Copy `.env.example` to `.env` (already included in the ZIP).
2. Paste credentials you have.
3. `pip install -r requirements.txt`
4. `streamlit run app.py`

Windows: double-click `start_windows.bat`.

## Zero-key demo
- DEMO1: two commercial sources agree on a >3h delay.
- DEMO2: cancellation.
- DEMO3: on-time / no trigger.

## Keys
- CIRIUM_APP_ID + CIRIUM_APP_KEY
- FLIGHTAWARE_API_KEY
- AERODATABOX_API_KEY

Production use requires appropriate commercial licensing / settlement rights.
