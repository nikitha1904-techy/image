import React from 'react';
import { 
  TableauIcon, ThoughtSpotIcon, ExcelIcon, MicroStrategyIcon, 
  ScalaIcon, AlteryxIcon, BrainCircuitIcon, NetworkIcon, SparkRealIcon
} from './Icons';

export const getActiveElements = (activeFlows) => {
  if (!activeFlows || activeFlows.length === 0) return null; // Default state: all active/normal
  
  const nodes = {
    tableau: false, thoughtspot: false, excel: false, microstrategy: false,
    python: false, spark: false, scala: false, alteryx: false,
    biSuite: false, etlSuite: false
  };
  
  const paths = {
    l1: false, l2: false, l3: false, l4: false,
    r1: false, r2: false, r3: false, r4: false
  };

  activeFlows.forEach(id => {
    // BI flows
    if (id.startsWith('sa-tab-')) { nodes.tableau = true; nodes.biSuite = true; paths.l1 = true; }
    if (id.startsWith('sa-exc-')) { nodes.excel = true; nodes.biSuite = true; paths.l3 = true; }
    if (id.startsWith('sa-ms-')) { nodes.microstrategy = true; nodes.biSuite = true; paths.l4 = true; }
    if (id.startsWith('sa-ts-')) { nodes.thoughtspot = true; nodes.biSuite = true; paths.l2 = true; }

    // ETL flows
    if (id === 'sa-etl-py-disc' || id === 'sa-etl-py-int' || id === 'sa-etl-py-rat') {
       nodes.python = true; nodes.etlSuite = true; paths.r1 = true;
    }
    if (id === 'sa-etl-sc-disc' || id === 'sa-etl-sc-int') {
       nodes.scala = true; nodes.etlSuite = true; paths.r3 = true;
    }
    if (id === 'sa-etl-spk-disc' || id === 'sa-etl-spk-int') {
       nodes.spark = true; nodes.etlSuite = true; paths.r2 = true;
    }
    if (id === 'sa-etl-alt-disc' || id === 'sa-etl-alt-rat') {
       nodes.alteryx = true; nodes.etlSuite = true; paths.r4 = true;
    }

    // ETL Migration
    if (id === 'sa-alt-mig') {
       nodes.alteryx = true; nodes.python = true; nodes.etlSuite = true; paths.r4 = true; paths.r1 = true;
    }
  });

  return { nodes, paths };
};

const ArchitectureDiagram = ({ activeFlows = [] }) => {
  const activeState = getActiveElements(activeFlows);

  // Helper to determine CSS classes for nodes
  const getNodeClass = (nodeKey) => {
    if (!activeState) return ''; // all normal
    return activeState.nodes[nodeKey] ? 'highlighted' : 'grayed-out';
  };

  // Helper to determine CSS classes for paths
  const getPathClass = (pathKey) => {
    if (!activeState) return ''; // all normal
    return activeState.paths[pathKey] ? 'animating-path' : 'grayed-out';
  };

  return (
    <div className="header-graphic" style={{ position: 'relative', width: '480px', height: '160px', margin: '0 auto' }}>
      <svg className="absolute inset-0" style={{position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0}}>
              {/* Left side lines */}
              <path id="path_l1" className={getPathClass('l1')} d="M 34 18 C 68 18, 68 45, 102 45" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
              <path id="path_l2" className={getPathClass('l2')} d="M 34 56 C 64 56, 64 65, 94 65" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
              <path id="path_l3" className={getPathClass('l3')} d="M 34 94 C 64 94, 64 85, 94 85" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
              <path id="path_l4" className={getPathClass('l4')} d="M 34 132 C 68 132, 68 105, 102 105" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />

              {/* Middle dotted lines connecting BI and ETL - kept mostly static or grayed out if filtering */}
              <path className={!activeState ? '' : 'grayed-out'} d="M 207 65 L 273 65" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
              <path className={!activeState ? '' : 'grayed-out'} d="M 207 75 L 273 75" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
              <path className={!activeState ? '' : 'grayed-out'} d="M 207 85 L 273 85" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />

              {/* Right side lines */}
              <path id="path_r1" className={getPathClass('r1')} d="M 378 45 C 412 45, 412 18, 446 18" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
              <path id="path_r2" className={getPathClass('r2')} d="M 386 65 C 416 65, 416 56, 446 56" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
              <path id="path_r3" className={getPathClass('r3')} d="M 386 85 C 416 85, 416 94, 446 94" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
              <path id="path_r4" className={getPathClass('r4')} d="M 378 105 C 412 105, 412 132, 446 132" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />

              {/* Animated Arrows */}
              {activeState && activeState.paths.l1 && (
                <g>
                  <path d="M -5 -4 L 5 0 L -5 4 z" fill="#f97316" />
                  <animateMotion dur="1s" repeatCount="indefinite" rotate="auto">
                    <mpath href="#path_l1" />
                  </animateMotion>
                </g>
              )}
              {activeState && activeState.paths.l2 && (
                <g>
                  <path d="M -5 -4 L 5 0 L -5 4 z" fill="#f97316" />
                  <animateMotion dur="1s" repeatCount="indefinite" rotate="auto">
                    <mpath href="#path_l2" />
                  </animateMotion>
                </g>
              )}
              {activeState && activeState.paths.l3 && (
                <g>
                  <path d="M -5 -4 L 5 0 L -5 4 z" fill="#f97316" />
                  <animateMotion dur="1s" repeatCount="indefinite" rotate="auto">
                    <mpath href="#path_l3" />
                  </animateMotion>
                </g>
              )}
              {activeState && activeState.paths.l4 && (
                <g>
                  <path d="M -5 -4 L 5 0 L -5 4 z" fill="#f97316" />
                  <animateMotion dur="1s" repeatCount="indefinite" rotate="auto">
                    <mpath href="#path_l4" />
                  </animateMotion>
                </g>
              )}
              {activeState && activeState.paths.r1 && (
                <g>
                  <path d="M -5 -4 L 5 0 L -5 4 z" fill="#f97316" />
                  <animateMotion dur="1s" repeatCount="indefinite" rotate="auto-reverse" keyPoints="1;0" keyTimes="0;1" calcMode="linear">
                    <mpath href="#path_r1" />
                  </animateMotion>
                </g>
              )}
              {activeState && activeState.paths.r2 && (
                <g>
                  <path d="M -5 -4 L 5 0 L -5 4 z" fill="#f97316" />
                  <animateMotion dur="1s" repeatCount="indefinite" rotate="auto-reverse" keyPoints="1;0" keyTimes="0;1" calcMode="linear">
                    <mpath href="#path_r2" />
                  </animateMotion>
                </g>
              )}
              {activeState && activeState.paths.r3 && (
                <g>
                  <path d="M -5 -4 L 5 0 L -5 4 z" fill="#f97316" />
                  <animateMotion dur="1s" repeatCount="indefinite" rotate="auto-reverse" keyPoints="1;0" keyTimes="0;1" calcMode="linear">
                    <mpath href="#path_r3" />
                  </animateMotion>
                </g>
              )}
              {activeState && activeState.paths.r4 && (
                <g>
                  <path d="M -5 -4 L 5 0 L -5 4 z" fill="#f97316" />
                  <animateMotion dur="1s" repeatCount="indefinite" rotate="auto-reverse" keyPoints="1;0" keyTimes="0;1" calcMode="linear">
                    <mpath href="#path_r4" />
                  </animateMotion>
                </g>
              )}
            </svg>

            {/* Left Column (BI Tools) */}
            <div style={{ position: 'absolute', left: 0, top: 0, display: 'flex', flexDirection: 'column', gap: '4px', zIndex: 1 }}>
              <div className={`small-logo-box ${getNodeClass('tableau')}`}><div style={{width: '26px', height: '26px'}}><TableauIcon /></div></div>
              <div className={`small-logo-box ${getNodeClass('thoughtspot')}`}><div style={{width: '26px', height: '26px'}}><ThoughtSpotIcon /></div></div>
              <div className={`small-logo-box ${getNodeClass('excel')}`}><div style={{width: '26px', height: '26px'}}><ExcelIcon /></div></div>
              <div className={`small-logo-box ${getNodeClass('microstrategy')}`}><div style={{width: '26px', height: '26px'}}><MicroStrategyIcon /></div></div>
            </div>
            
            {/* Left Circle: BI Suite */}
            <div className={`graphic-circle bi ${getNodeClass('biSuite')}`} style={{position: 'absolute', left: '105px', top: '30px', zIndex: 1}}>
              <BrainCircuitIcon />
              <span style={{top: 'calc(100% + 18px)'}}>BI Suite</span>
            </div>
            
            {/* Right Circle: ETL Suite */}
            <div className={`graphic-circle etl ${getNodeClass('etlSuite')}`} style={{position: 'absolute', left: '285px', top: '30px', zIndex: 1}}>
              <NetworkIcon />
              <span style={{top: 'calc(100% + 18px)'}}>ETL Suite</span>
            </div>
            
            {/* Right Column (ETL Tools) */}
            <div style={{ position: 'absolute', left: '446px', top: 0, display: 'flex', flexDirection: 'column', gap: '4px', zIndex: 1 }}>
              <div className={`small-logo-box ${getNodeClass('python')}`}><img src="/python_real.svg" alt="Python" style={{width: '26px', height: '26px', objectFit: 'contain'}} /></div>
              <div className={`small-logo-box ${getNodeClass('spark')}`}><div style={{width: '26px', height: '26px'}}><SparkRealIcon /></div></div>
              <div className={`small-logo-box ${getNodeClass('scala')}`}><div style={{width: '26px', height: '26px'}}><ScalaIcon /></div></div>
              <div className={`small-logo-box ${getNodeClass('alteryx')}`}><div style={{width: '26px', height: '26px'}}><AlteryxIcon /></div></div>
            </div>
    </div>
  );
};

export default ArchitectureDiagram;
