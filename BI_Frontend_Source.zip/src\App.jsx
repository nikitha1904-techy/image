import React from 'react';
import './index.css';
import AgentCard from './components/AgentCard';

// Core SVGs
const SearchIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="10" cy="10" r="6"></circle>
    <line x1="21" y1="21" x2="14.5" y2="14.5"></line>
  </svg>
);

const BrainCircuitIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ transform: 'scale(1.3)' }}>
    <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/>
    <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/>
    <path d="M15 13a4.5 4.5 0 0 1-3-4"/>
    <path d="M17.599 6.5a3 3 0 0 0 .399-1.375"/>
    <path d="M6.003 5.125A3 3 0 0 0 6.401 6.5"/>
    <path d="M3.477 10.896a4 4 0 0 1 .585-.396"/>
    <path d="M19.938 10.5a4 4 0 0 1 .585.396"/>
    <path d="M6 18a4 4 0 0 1-1.967-.516"/>
    <path d="M19.967 17.484A4 4 0 0 1 18 18"/>
  </svg>
);

const ScaleIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3v18" />
    <path d="M9 21h6" />
    <path d="M4 7h16" />
    <path d="M4 7l-2 8h4l-2-8z" />
    <path d="M2 15s1 2 2 2 2-2 2-2" />
    <path d="M20 7l-2 8h4l-2-8z" />
    <path d="M18 15s1 2 2 2 2-2 2-2" />
    <circle cx="12" cy="7" r="1" fill="currentColor" />
  </svg>
);

const RocketIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"></path>
    <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"></path>
    <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"></path>
    <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"></path>
  </svg>
);

const NetworkIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3" />
    <rect x="4" y="4" width="4" height="4" rx="1" />
    <path d="M7.5 7.5L10 10" />
    <rect x="16" y="4" width="4" height="4" rx="1" />
    <path d="M16.5 7.5L14 10" />
    <rect x="4" y="16" width="4" height="4" rx="1" />
    <path d="M7.5 16.5L10 14" />
    <rect x="16" y="16" width="4" height="4" rx="1" />
    <path d="M16.5 16.5L14 14" />
    <circle cx="3" cy="12" r="1.5" />
    <path d="M4.5 12h4.5" />
    <circle cx="21" cy="12" r="1.5" />
    <path d="M19.5 12h-4.5" />
  </svg>
);

const ClipboardIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
    <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
    <path d="M9 14l2 2 4-4"></path>
  </svg>
);

const SectionChartIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
    <path d="M3 2v20h20v-2H5V2H3z" />
    <rect x="7" y="14" width="3" height="6" />
    <rect x="12" y="10" width="3" height="10" />
    <rect x="17" y="6" width="3" height="14" />
  </svg>
);

const DatabaseIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
    <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path>
    <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
    <path d="M12 12v-7"></path>
    <path d="m9 8 3-3 3 3"></path>
  </svg>
);

const SectionDatabaseIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
    <path d="M3 5v4c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
    <path d="M3 9v4c0 1.66 4 3 9 3s9-1.34 9-3V9"></path>
    <path d="M3 13v4c0 1.66 4 3 9 3s9-1.34 9-3v-4"></path>
  </svg>
);

// Specific Tool Icons for the diagram
const TableauIcon = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
    <path d="M12 9v6M9 12h6" stroke="#1C4B82" strokeWidth="2.5" strokeLinecap="round" />
    <path d="M6 6h4M8 4v4" stroke="#E8762D" strokeWidth="2" strokeLinecap="round" />
    <path d="M14 6h4M16 4v4" stroke="#5B879B" strokeWidth="2" strokeLinecap="round" />
    <path d="M6 16h4M8 14v4" stroke="#21A366" strokeWidth="2" strokeLinecap="round" />
    <path d="M14 16h4M16 14v4" stroke="#1C4B82" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const LeftBarChartIcon = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="#000">
    <path d="M3 2v20h20v-2H5V2H3z" />
    <rect x="7" y="10" width="3" height="10" />
    <rect x="12" y="14" width="3" height="6" />
    <rect x="17" y="6" width="3" height="14" />
  </svg>
);

const ExcelIcon = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
    <rect x="3" y="4" width="18" height="16" rx="2" fill="#21A366"/>
    <path d="M7.5 16L10 12L7.5 8H9.5L11 10.5L12.5 8H14.5L12 12L14.5 16H12.5L11 13.5L9.5 16H7.5Z" fill="white"/>
  </svg>
);

const SnowflakeIcon = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#29B5E8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 2v20M12 2l3 3M12 2L9 5M12 22l3-3M12 22l-3-3M2 12h20M2 12l3-3M2 12l3 3M22 12l-3-3M22 12l-3 3M5 5l14 14M5 5l4 0M5 5l0 4M19 19l-4 0M19 19l0-4M5 19l14-14M5 19l4 0M5 19l0-4M19 5l-4 0M19 5l0 4" />
  </svg>
);

const DatabricksIcon = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#FF3621" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3l8 4-8 4-8-4z" />
    <path d="M4 11l8 4 8-4" />
    <path d="M4 15l8 4 8-4" />
  </svg>
);

const AWSIcon = () => (
  <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
    <text x="3" y="14" fill="#232F3E" fontSize="12" fontWeight="800" fontFamily="Arial">aws</text>
    <path d="M4 16c2 2 5 2.5 8 2.5 3 0 6-.5 8-2.5" stroke="#FF9900" strokeWidth="2" strokeLinecap="round" fill="none"/>
    <path d="M18 14.5l2 1.5-1.5 2" stroke="#FF9900" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none"/>
  </svg>
);

function App() {
  const [biMigrationSelected, setBiMigrationSelected] = React.useState(false);
  const [biMigrationSubAgent, setBiMigrationSubAgent] = React.useState(null);

  const handleBiGetStarted = (e) => {
    e.preventDefault();
    if (biMigrationSelected) {
      if (biMigrationSubAgent === 'sa-tab-pbi') {
        // [INSERT TABLEAU TO POWER BI LINK HERE]
        window.open('https://your-tableau-link-here.com', '_blank');
      } else if (biMigrationSubAgent === 'sa-ts-pbi') {
        // [INSERT THOUGHTSPOT TO POWER BI LINK HERE]
        window.open('https://your-thoughtspot-link-here.com', '_blank');
      } else if (biMigrationSubAgent === 'sa-ms-pbi') {
        // [INSERT MICROSTRATEGY TO POWER BI LINK HERE]
        window.open('https://your-microstrategy-link-here.com', '_blank');
      } else {
        alert("Please select a specific migration agent (Tableau, ThoughtSpot, or MicroStrategy).");
      }
    } else {
      alert("Please select the BI MIGRATION AGENT checkbox first.");
    }
  };

  return (
    <div className="container">
      {/* Header Section */}
      <div className="header-section">
        <div className="header-content">
          <div className="header-welcome">Welcome to</div>
          <h1 className="header-title">Modernization Suite</h1>
          <p className="header-subtitle">
            Transform your BI and ETL ecosystems with a suite of AI-powered agents.
          </p>
          <p className="header-instruction">
            Select the agents you want to run and get started.
          </p>
        </div>
        
        {/* Right Graphic */}
        <div className="header-graphic">
          {/* Connection Lines (SVG) */}
          <svg className="absolute inset-0" style={{position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0}}>
            {/* Left side lines flowing into BI Suite */}
            {/* Y coordinates align perfectly with icon centers: 16, 52, 88, 124 */}
            <path d="M 46 16 C 90 16, 90 44, 130 44" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" fill="none" />
            <path d="M 46 52 C 90 52, 90 56, 130 56" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" fill="none" />
            <path d="M 46 88 C 90 88, 90 68, 130 68" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" fill="none" />
            <path d="M 46 124 C 90 124, 90 80, 130 80" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" fill="none" />

            {/* Middle dotted lines connecting BI and ETL */}
            <path d="M 230 54 L 320 54" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" fill="none" />
            <path d="M 230 62 L 320 62" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" fill="none" />
            <path d="M 230 70 L 320 70" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" fill="none" />

            {/* Right side lines flowing out of ETL Suite */}
            {/* Extended X to 514 to touch the right icons. Centers at 16, 52, 88, 124 */}
            <path d="M 420 44 C 470 44, 470 16, 514 16" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" fill="none" />
            <path d="M 420 56 C 470 56, 470 52, 514 52" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" fill="none" />
            <path d="M 420 68 C 470 68, 470 88, 514 88" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" fill="none" />
            <path d="M 420 80 C 470 80, 470 124, 514 124" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" fill="none" />
          </svg>

          {/* Left Column (BI Tools) */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', zIndex: 1, paddingLeft: '14px', alignSelf: 'center' }}>
            <div className="small-logo-box"><TableauIcon /></div>
            <div className="small-logo-box"><LeftBarChartIcon /></div>
            <div className="small-logo-box"><ExcelIcon /></div>
            <div style={{color: '#000000', fontWeight: 'bold', textAlign: 'center', lineHeight: '32px', fontSize: '20px', letterSpacing: '2px', height: '32px'}}>...</div>
          </div>
          
          <div className="graphic-circle bi" style={{marginLeft: '20px'}}>
            <BrainCircuitIcon />
            <span style={{top: 'calc(100% + 18px)'}}>BI Suite</span>
          </div>
          
          <div className="graphic-circle etl" style={{marginRight: '20px'}}>
            <NetworkIcon />
            <span style={{top: 'calc(100% + 18px)'}}>ETL Suite</span>
          </div>
          
          {/* Right Column (ETL Tools) */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', zIndex: 1, paddingRight: '4px', alignSelf: 'center' }}>
            <div className="small-logo-box"><SnowflakeIcon /></div>
            <div className="small-logo-box"><DatabricksIcon /></div>
            <div className="small-logo-box"><AWSIcon /></div>
            <div style={{color: '#000000', fontWeight: 'bold', textAlign: 'center', lineHeight: '32px', fontSize: '20px', letterSpacing: '2px', height: '32px'}}>...</div>
          </div>
        </div>
      </div>

      {/* BI Modernization Suite Section */}
      <div className="suite-section">
        <div className="section-header">
          <div className="section-title-wrap">
            <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
              <div className="section-header-icon" style={{color: 'var(--orange-btn)'}}><SectionChartIcon /></div>
              <h2 className="section-title bi" style={{margin: 0}}>BI MODERNIZATION SUITE</h2>
            </div>
            <p style={{marginLeft: '28px', marginTop: '4px'}}>Transform your BI ecosystem with intelligent agents.</p>
          </div>
          <a href="#" className="btn-primary orange" onClick={handleBiGetStarted}>
            Get Started &rarr;
          </a>
        </div>
        
        <div className="card-grid">
          <AgentCard 
            theme="orange"
            iconSvg={<SearchIcon />}
            title="1. BI DISCOVERY AGENT"
            subtitle="Find & Catalog Every Asset"
            description="Automatically discover and catalog dashboards, reports and dependencies."
          />
          <AgentCard 
            theme="orange"
            iconSvg={<BrainCircuitIcon />}
            title="2. BI INTELLIGENCE AGENT"
            subtitle="Understand Every Dashboard"
            description="Extract metadata, visuals, KPIs, data models and business context from every dashboard."
          />
          <AgentCard 
            theme="orange"
            iconSvg={<ScaleIcon />}
            title="3. BI RATIONALISATION AGENT"
            subtitle="Decide What to Keep"
            description="Identify duplicates, assess value and recommend keep, consolidate or retire."
            subAgents={[
              { id: 'sa-tab-rat', label: 'Tableau Rationalisation' },
              { id: 'sa-exc-rat', label: 'Excel Rationalisation' }
            ]}
          />
          <AgentCard 
            theme="orange"
            iconSvg={<RocketIcon />}
            title="4. BI MIGRATION AGENT"
            subtitle="Convert to Target Platform"
            description="Convert, validate and export assets to modern BI platforms."
            subAgents={[
              { id: 'sa-tab-pbi', label: 'Tableau to Power BI Migration' },
              { id: 'sa-ts-pbi', label: 'ThoughtSpot to Power BI Migration' },
              { id: 'sa-ms-pbi', label: 'MicroStrategy to Power BI Migration' }
            ]}
            onSelectionChange={(isSelected) => setBiMigrationSelected(isSelected)}
            onSubAgentChange={(subAgentId) => setBiMigrationSubAgent(subAgentId)}
          />
        </div>
      </div>

      {/* ETL Modernization Suite Section */}
      <div className="suite-section" style={{marginTop: '16px'}}>
        <div className="section-header">
          <div className="section-title-wrap">
            <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
              <div className="section-header-icon" style={{color: 'var(--blue-btn)'}}><SectionDatabaseIcon /></div>
              <h2 className="section-title etl" style={{margin: 0}}>ETL MODERNIZATION SUITE</h2>
            </div>
            <p style={{marginLeft: '28px', marginTop: '4px'}}>Modernize your ETL landscape with intelligent agents.</p>
          </div>
          <a href="#" className="btn-primary blue">
            Get Started &rarr;
          </a>
        </div>
        
        <div className="card-grid">
          <AgentCard 
            theme="blue"
            iconSvg={<SearchIcon />}
            title="1. ETL DISCOVERY AGENT"
            subtitle="Discover & Inventory ETL Assets"
            description="Discover pipelines, jobs, mappings, schedules and metadata across your ETL ecosystem."
          />
          <AgentCard 
            theme="blue"
            iconSvg={<NetworkIcon />}
            title="2. ETL INTELLIGENCE AGENT"
            subtitle="Extract Lineage & Understand"
            description="Extract end-to-end data lineage, transformations, business rules and technical metadata."
          />
          <AgentCard 
            theme="blue"
            iconSvg={<ClipboardIcon />}
            title="3. ETL RATIONALISATION AGENT"
            subtitle="Analyze, Assess & Recommend"
            description="Identify redundant pipelines, assess complexity and recommend keep, consolidate, or retire."
          />
          <AgentCard 
            theme="blue"
            iconSvg={<DatabaseIcon />}
            title="4. ETL MIGRATION AGENT"
            subtitle="Migrate & Validate with Confidence"
            description="Perform source validation, impact analysis, mapping and migrate pipelines to target platforms."
            subAgents={[
              { id: 'sa-inf-db', label: 'Informatica to Databricks' },
              { id: 'sa-ds-adf', label: 'DataStage to Azure Data Factory' },
              { id: 'sa-alt-py', label: 'Alteryx to Python' }
            ]}
          />
        </div>
      </div>
    </div>
  );
}

export default App;
