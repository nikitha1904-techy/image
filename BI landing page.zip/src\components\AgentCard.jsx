import React, { useState } from 'react';

const AgentCard = ({ 
  theme, // 'purple', 'blue', 'green', 'orange'
  title, 
  subtitle, 
  description, 
  iconSvg,
  subAgents = [], // Array of { id, label }
  onSelectionChange,
  onSubAgentChange
}) => {
  const [selected, setSelected] = useState(false);
  const [selectedSubAgent, setSelectedSubAgent] = useState(null);

  const handleSelect = () => {
    const newVal = !selected;
    setSelected(newVal);
    if (onSelectionChange) onSelectionChange(newVal);
  };

  const handleSubAgentSelect = (id) => {
    setSelectedSubAgent(id);
    if (onSubAgentChange) onSubAgentChange(id);
  };

  const themeClass = `theme-${theme}`;

  return (
    <div className={`agent-card ${theme} ${selected ? 'selected' : ''}`}>
      {/* Checkbox */}
      <button 
        className={`card-checkbox ${selected ? 'checked' : ''}`} 
        onClick={handleSelect}
        aria-label={`Select ${title}`}
      >
        {selected && (
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
            <polyline points="20 6 9 17 4 12"></polyline>
          </svg>
        )}
      </button>

      {/* Header Row: Icon + Titles */}
      <div className="card-header-row">
        <div className={`card-icon ${theme}`}>
          {iconSvg}
        </div>
        <div className="card-title-stack">
          <h3 className={`card-title ${theme}`}>{title}</h3>
          <h4 className="card-subtitle">{subtitle}</h4>
        </div>
      </div>

      {/* Content */}
      <p className="card-desc">{description}</p>

      {/* Sub Agents Section */}
      {subAgents.length > 0 && (
        <div className="sub-agents-section">
          <h5 className="sub-agents-title">Sub Agents (Select any one)</h5>
          {subAgents.map((sa) => (
            <div key={sa.id} className="sub-agent-item">
              <label className="sub-agent-radio-label" onClick={() => handleSubAgentSelect(sa.id)}>
                <span className={`sub-agent-radio ${themeClass} ${selectedSubAgent === sa.id ? 'selected' : ''}`} />
                {sa.label}
              </label>
              <button className="btn-options">
                Options 
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                  <circle cx="12" cy="12" r="3"></circle>
                  <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z"></path>
                </svg>
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AgentCard;

