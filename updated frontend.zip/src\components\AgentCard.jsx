import React, { useState } from 'react';

const AgentCard = ({ 
  theme, // 'purple', 'blue', 'green', 'orange'
  title, 
  subtitle, 
  description, 
  iconSvg,
  subAgents = [], // Array of { id, label }
  onSelectionChange,
  onSubAgentChange
}) => {
  const [selected, setSelected] = useState(false);
  const [selectedSubAgent, setSelectedSubAgent] = useState(null);

  const handleSelect = () => {
    const newVal = !selected;
    setSelected(newVal);
    if (onSelectionChange) onSelectionChange(newVal);
  };

  const handleSubAgentSelect = (id) => {
    setSelectedSubAgent(id);
    if (onSubAgentChange) onSubAgentChange(id);
  };

  const themeClass = `theme-${theme}`;

  return (
    <div className={`agent-card ${theme} ${selected ? 'selected' : ''}`}>
      {/* Header Row: Checkbox + Icon + Titles */}
      <div className="card-header-row">
        <button 
          className={`card-checkbox ${selected ? 'checked' : ''}`} 
          onClick={handleSelect}
          aria-label={`Select ${title}`}
        >
          {selected && (
            <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round">
              <polyline points="20 6 9 17 4 12"></polyline>
            </svg>
          )}
        </button>
        <div className={`card-icon ${theme}`}>
          {iconSvg}
        </div>
        <div className="card-title-stack">
          <h3 className={`card-title ${theme}`}>{title}</h3>
          <h4 className="card-subtitle">{subtitle}</h4>
        </div>
      </div>

      {/* Content */}
      <p className="card-desc">{description}</p>

      {/* Sub Agents Section */}
      {subAgents.length > 0 && (
        <div className="sub-agents-section">
          <h5 className="sub-agents-title">Sub Agents (Select any one)</h5>
          {subAgents.map((sa) => (
            <div key={sa.id} className="sub-agent-item">
              <label className={`sub-agent-radio-label ${sa.isWip ? 'wip' : ''}`} onClick={() => handleSubAgentSelect(sa.id)}>
                <span className={`sub-agent-radio ${themeClass} ${selectedSubAgent === sa.id ? 'selected' : ''}`} />
                {sa.label}
                {sa.isWip && <span className="wip-legend">WIP</span>}
              </label>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default AgentCard;

