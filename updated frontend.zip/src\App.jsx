import React from 'react';
import './index.css';
import AgentCard from './components/AgentCard';

// Core SVGs
const SearchIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="10" cy="10" r="6"></circle>
    <line x1="21" y1="21" x2="14.5" y2="14.5"></line>
  </svg>
);

const BrainCircuitIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" style={{ transform: 'scale(1.3)' }}>
    <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z"/>
    <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z"/>
    <path d="M15 13a4.5 4.5 0 0 1-3-4"/>
    <path d="M17.599 6.5a3 3 0 0 0 .399-1.375"/>
    <path d="M6.003 5.125A3 3 0 0 0 6.401 6.5"/>
    <path d="M3.477 10.896a4 4 0 0 1 .585-.396"/>
    <path d="M19.938 10.5a4 4 0 0 1 .585.396"/>
    <path d="M6 18a4 4 0 0 1-1.967-.516"/>
    <path d="M19.967 17.484A4 4 0 0 1 18 18"/>
  </svg>
);

const ScaleIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 3v18" />
    <path d="M9 21h6" />
    <path d="M4 7h16" />
    <path d="M4 7l-2 8h4l-2-8z" />
    <path d="M2 15s1 2 2 2 2-2 2-2" />
    <path d="M20 7l-2 8h4l-2-8z" />
    <path d="M18 15s1 2 2 2 2-2 2-2" />
    <circle cx="12" cy="7" r="1" fill="currentColor" />
  </svg>
);

const RocketIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4.5 16.5c-1.5 1.26-2 5-2 5s3.74-.5 5-2c.71-.84.7-2.13-.09-2.91a2.18 2.18 0 0 0-2.91-.09z"></path>
    <path d="m12 15-3-3a22 22 0 0 1 2-3.95A12.88 12.88 0 0 1 22 2c0 2.72-.78 7.5-6 11a22.35 22.35 0 0 1-4 2z"></path>
    <path d="M9 12H4s.55-3.03 2-4c1.62-1.08 5 0 5 0"></path>
    <path d="M12 15v5s3.03-.55 4-2c1.08-1.62 0-5 0-5"></path>
  </svg>
);

const NetworkIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="3" />
    <rect x="4" y="4" width="4" height="4" rx="1" />
    <path d="M7.5 7.5L10 10" />
    <rect x="16" y="4" width="4" height="4" rx="1" />
    <path d="M16.5 7.5L14 10" />
    <rect x="4" y="16" width="4" height="4" rx="1" />
    <path d="M7.5 16.5L10 14" />
    <rect x="16" y="16" width="4" height="4" rx="1" />
    <path d="M16.5 16.5L14 14" />
    <circle cx="3" cy="12" r="1.5" />
    <path d="M4.5 12h4.5" />
    <circle cx="21" cy="12" r="1.5" />
    <path d="M19.5 12h-4.5" />
  </svg>
);

const ClipboardIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path>
    <rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect>
    <path d="M9 14l2 2 4-4"></path>
  </svg>
);

const SectionChartIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
    <path d="M3 2v20h20v-2H5V2H3z" />
    <rect x="7" y="14" width="3" height="6" />
    <rect x="12" y="10" width="3" height="10" />
    <rect x="17" y="6" width="3" height="14" />
  </svg>
);

const DatabaseIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
    <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"></path>
    <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
    <path d="M12 12v-7"></path>
    <path d="m9 8 3-3 3 3"></path>
  </svg>
);

const SectionDatabaseIcon = () => (
  <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <ellipse cx="12" cy="5" rx="9" ry="3"></ellipse>
    <path d="M3 5v4c0 1.66 4 3 9 3s9-1.34 9-3V5"></path>
    <path d="M3 9v4c0 1.66 4 3 9 3s9-1.34 9-3V9"></path>
    <path d="M3 13v4c0 1.66 4 3 9 3s9-1.34 9-3v-4"></path>
  </svg>
);

// Official Tool SVG Components
const TableauIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" style={{width: '100%', height: '100%'}}>
    <path d="M12 9v6M9 12h6" stroke="#1C4B82" strokeWidth="2.5" strokeLinecap="round" />
    <path d="M6 6h4M8 4v4" stroke="#E8762D" strokeWidth="2" strokeLinecap="round" />
    <path d="M14 6h4M16 4v4" stroke="#5B879B" strokeWidth="2" strokeLinecap="round" />
    <path d="M6 16h4M8 14v4" stroke="#21A366" strokeWidth="2" strokeLinecap="round" />
    <path d="M14 16h4M16 14v4" stroke="#1C4B82" strokeWidth="2" strokeLinecap="round" />
  </svg>
);

const PowerBIIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" style={{width: '100%', height: '100%'}}>
    <rect x="4" y="12" width="4.5" height="10" rx="1" fill="#F6D75C"/>
    <rect x="9.75" y="7" width="4.5" height="15" rx="1" fill="#EBB72E"/>
    <rect x="15.5" y="2" width="4.5" height="20" rx="1" fill="#E09A0F"/>
  </svg>
);

const ExcelIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" style={{width: '100%', height: '100%'}}>
    <rect x="2" y="3" width="20" height="18" rx="2" fill="#21A366"/>
    <path d="M7 16L10 12L7 8H9L11 10.5L13 8H15L12 12L15 16H13L11 13.5L9 16H7Z" fill="white"/>
  </svg>
);

const MicroStrategyIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" style={{width: '100%', height: '100%'}}>
    <circle cx="12" cy="12" r="11" fill="#D9232E"/>
    <rect x="6" y="7" width="3.5" height="10" fill="white"/>
    <rect x="10.5" y="7" width="3.5" height="10" fill="white"/>
    <path d="M15 17h3.5V9.5L15 7v10z" fill="white"/>
  </svg>
);

const ScalaIcon = () => (
  <svg viewBox="0 0 256 416" fill="none" style={{width: '100%', height: '100%'}}>
    <defs>
      <linearGradient x1="0%" y1="50%" y2="50%" id="a"><stop stopColor="#4F4F4F" offset="0%"/><stop offset="100%"/></linearGradient>
      <linearGradient x1="0%" y1="50%" y2="50%" id="b"><stop stopColor="#C40000" offset="0%"/><stop stopColor="#F00" offset="100%"/></linearGradient>
    </defs>
    <path d="M0 288v-32c0-5.394 116.377-14.428 192.2-32 36.628 8.49 63.8 18.969 63.8 32v32c0 13.024-27.172 23.51-63.8 32C116.376 302.425 0 293.39 0 288" fill="url(#a)" transform="matrix(1 0 0 -1 0 544)"/>
    <path d="M0 160v-32c0-5.394 116.377-14.428 192.2-32 36.628 8.49 63.8 18.969 63.8 32v32c0 13.024-27.172 23.51-63.8 32C116.376 174.425 0 165.39 0 160" fill="url(#a)" transform="matrix(1 0 0 -1 0 288)"/>
    <path d="M0 224v-96c0 8 256 24 256 64v96c0-40-256-56-256-64" fill="url(#b)" transform="matrix(1 0 0 -1 0 416)"/>
    <path d="M0 96V0c0 8 256 24 256 64v96c0-40-256-56-256-64" fill="url(#b)" transform="matrix(1 0 0 -1 0 160)"/>
    <path d="M0 352v-96c0 8 256 24 256 64v96c0-40-256-56-256-64" fill="url(#b)" transform="matrix(1 0 0 -1 0 672)"/>
  </svg>
);

const AlteryxIcon = () => (
  <svg viewBox="0 0 24 24" fill="none" style={{width: '100%', height: '100%'}}>
    <circle cx="12" cy="12" r="11" fill="#1C84C6"/>
    <text x="12" y="16.5" fontFamily="Arial, Helvetica, sans-serif" fontSize="15" fontWeight="bold" fill="white" textAnchor="middle">a</text>
  </svg>
);

const MoonIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
  </svg>
);

const SunIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="5"></circle>
    <line x1="12" y1="1" x2="12" y2="3"></line>
    <line x1="12" y1="21" x2="12" y2="23"></line>
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
    <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
    <line x1="1" y1="12" x2="3" y2="12"></line>
    <line x1="21" y1="12" x2="23" y2="12"></line>
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
    <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
  </svg>
);

const biSubAgents = [
  { id: 'sa-tab-pbi', label: 'Tableau to Power BI Migration' },
  { id: 'sa-ts-pbi', label: 'ThoughtSpot to Power BI Migration' },
  { id: 'sa-ms-pbi', label: 'MicroStrategy to Power BI Migration', isWip: true },
  { id: 'sa-exc-rat', label: 'Excel Rationalisation', isWip: true }
];

const etlIntelligenceSubAgents = [
  { id: 'sa-etl-py', label: 'Python', isWip: true },
  { id: 'sa-etl-sc', label: 'Scala', isWip: true },
  { id: 'sa-etl-spk', label: 'Spark SQL/PySpark', isWip: true }
];

const etlMigrationSubAgents = [
  { id: 'sa-alt-py', label: 'Alteryx to Python' }
];

function App() {
  const [biMigrationSelected, setBiMigrationSelected] = React.useState(false);
  const [biMigrationSubAgent, setBiMigrationSubAgent] = React.useState(null);
  const [isDarkMode, setIsDarkMode] = React.useState(false);

  React.useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark-mode');
    } else {
      document.documentElement.classList.remove('dark-mode');
    }
  }, [isDarkMode]);

  const handleBiGetStarted = (e) => {
    e.preventDefault();
    if (biMigrationSelected) {
      if (biMigrationSubAgent === 'sa-tab-pbi') {
        // [INSERT TABLEAU TO POWER BI LINK HERE]
        window.open('https://your-tableau-link-here.com', '_blank');
      } else if (biMigrationSubAgent === 'sa-ts-pbi') {
        // [INSERT THOUGHTSPOT TO POWER BI LINK HERE]
        window.open('https://your-thoughtspot-link-here.com', '_blank');
      } else if (biMigrationSubAgent === 'sa-ms-pbi') {
        // [INSERT MICROSTRATEGY TO POWER BI LINK HERE]
        window.open('https://your-microstrategy-link-here.com', '_blank');
      } else {
        alert("Please select a specific migration agent (Tableau, ThoughtSpot, or MicroStrategy).");
      }
    } else {
      alert("Please select the BI MIGRATION AGENT checkbox first.");
    }
  };

  return (
    <>
      {/* Dark Mode Toggle */}
      <button 
        onClick={() => setIsDarkMode(!isDarkMode)} 
        style={{ position: 'fixed', top: '24px', right: '12px', background: 'transparent', border: 'none', cursor: 'pointer', color: 'var(--text-main)', zIndex: 1000 }}
      >
        {isDarkMode ? <SunIcon /> : <MoonIcon />}
      </button>

      <div className="container" style={{position: 'relative'}}>
        {/* Header Section */}
        <div className="header-section">
        <div className="header-content">
          <h1 className="header-title">EXL Modernization Suite</h1>
          <p className="header-subtitle">
            Transform your BI and ETL ecosystems with a suite of AI-powered agents.
          </p>
          <p className="header-instruction">
            Select the agents you want to run and get started.
          </p>
        </div>
        
        {/* Right Graphic */}
        <div className="header-graphic">
          {/* Connection Lines (SVG) */}
          <svg className="absolute inset-0" style={{position: 'absolute', top: 0, left: 0, width: '100%', height: '100%', zIndex: 0}}>
            {/* Left side lines flowing into BI Suite (Starts X=34, Connects X=102) */}
            <path d="M 34 18 C 68 18, 68 45, 102 45" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
            <path d="M 34 56 C 64 56, 64 65, 94 65" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
            <path d="M 34 94 C 64 94, 64 85, 94 85" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
            <path d="M 34 132 C 68 132, 68 105, 102 105" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />

            {/* Middle dotted lines connecting BI and ETL (Starts X=207, Connects X=273) */}
            <path d="M 207 65 L 273 65" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
            <path d="M 207 75 L 273 75" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
            <path d="M 207 85 L 273 85" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />

            {/* Right side lines flowing out of ETL Suite (Starts X=378, Connects X=446) */}
            <path d="M 378 45 C 412 45, 412 18, 446 18" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
            <path d="M 386 65 C 416 65, 416 56, 446 56" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
            <path d="M 386 85 C 416 85, 416 94, 446 94" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
            <path d="M 378 105 C 412 105, 412 132, 446 132" stroke="#9CA3AF" strokeWidth="1.75" strokeDasharray="4 4" fill="none" />
          </svg>

          {/* Left Column (BI Tools) */}
          <div style={{ position: 'absolute', left: 0, top: 0, display: 'flex', flexDirection: 'column', gap: '4px', zIndex: 1 }}>
            <div className="small-logo-box"><div style={{width: '26px', height: '26px'}}><TableauIcon /></div></div>
            <div className="small-logo-box"><div style={{width: '26px', height: '26px'}}><PowerBIIcon /></div></div>
            <div className="small-logo-box"><div style={{width: '26px', height: '26px'}}><ExcelIcon /></div></div>
            <div className="small-logo-box"><div style={{width: '26px', height: '26px'}}><MicroStrategyIcon /></div></div>
          </div>
          
          {/* Left Circle: BI Suite */}
          <div className="graphic-circle bi" style={{position: 'absolute', left: '105px', top: '30px', zIndex: 1}}>
            <BrainCircuitIcon />
            <span style={{top: 'calc(100% + 18px)'}}>BI Suite</span>
          </div>
          
          {/* Right Circle: ETL Suite */}
          <div className="graphic-circle etl" style={{position: 'absolute', left: '285px', top: '30px', zIndex: 1}}>
            <NetworkIcon />
            <span style={{top: 'calc(100% + 18px)'}}>ETL Suite</span>
          </div>
          
          {/* Right Column (ETL Tools) */}
          <div style={{ position: 'absolute', left: '446px', top: 0, display: 'flex', flexDirection: 'column', gap: '4px', zIndex: 1 }}>
            <div className="small-logo-box"><img src="/python_real.svg" alt="Python" style={{width: '26px', height: '26px', objectFit: 'contain'}} /></div>
            <div className="small-logo-box"><img src="/spark_real.svg" alt="Spark" style={{width: '26px', height: '26px', objectFit: 'contain'}} /></div>
            <div className="small-logo-box"><div style={{width: '26px', height: '26px'}}><ScalaIcon /></div></div>
            <div className="small-logo-box"><div style={{width: '26px', height: '26px'}}><AlteryxIcon /></div></div>
          </div>
        </div>
      </div>

      {/* BI Modernization Suite Section */}
      <div className="suite-section">
        <div className="section-header">
          <div className="section-title-wrap">
            <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
              <div className="section-header-icon" style={{color: 'var(--blue-btn)'}}><SectionChartIcon /></div>
              <h2 className="section-title bi" style={{margin: 0, color: 'var(--blue-btn)'}}>BI MODERNIZATION AGENT</h2>
            </div>
            <p style={{marginLeft: '28px', marginTop: '4px'}}>Transform your BI ecosystem with intelligent agents.</p>
          </div>
        </div>
        
        <div className="card-grid">
          <AgentCard 
            theme="orange"
            iconSvg={<SearchIcon />}
            title="1. BI DISCOVERY AGENT"
            subtitle="Find & Catalog Every Asset"
            description="Automatically discover and catalog dashboards, reports and dependencies."
            subAgents={biSubAgents}
          />
          <AgentCard 
            theme="orange"
            iconSvg={<BrainCircuitIcon />}
            title="2. BI INTELLIGENCE AGENT"
            subtitle="Understand Every Dashboard"
            description="Extract metadata, visuals, KPIs, data models and business context from every dashboard."
            subAgents={biSubAgents}
          />
          <AgentCard 
            theme="orange"
            iconSvg={<ScaleIcon />}
            title="3. BI RATIONALISATION AGENT"
            subtitle="Decide What to Keep"
            description="Identify duplicates, assess value and recommend keep, consolidate or retire."
            subAgents={biSubAgents}
          />
          <AgentCard 
            theme="orange"
            iconSvg={<RocketIcon />}
            title="4. BI MIGRATION AGENT"
            subtitle="Convert to Target Platform"
            description="Convert, validate and export assets to modern BI platforms."
            subAgents={biSubAgents}
            onSelectionChange={(isSelected) => setBiMigrationSelected(isSelected)}
            onSubAgentChange={(subAgentId) => setBiMigrationSubAgent(subAgentId)}
          />
        </div>
        <div className="section-footer">
          <a href="#" className="btn-primary blue" onClick={handleBiGetStarted}>
            Get Started &rarr;
          </a>
        </div>
      </div>

      {/* ETL Modernization Suite Section */}
      <div className="suite-section" style={{marginTop: '16px'}}>
        <div className="section-header">
          <div className="section-title-wrap">
            <div style={{display: 'flex', alignItems: 'center', gap: '8px'}}>
              <div className="section-header-icon" style={{color: 'var(--blue-btn)'}}><SectionDatabaseIcon /></div>
              <h2 className="section-title" style={{margin: 0, color: 'var(--blue-btn)'}}>ETL MODERNIZATION AGENT</h2>
            </div>
            <p style={{marginLeft: '28px', marginTop: '4px'}}>Modernize your ETL landscape with intelligent agents.</p>
          </div>
        </div>
        
        <div className="card-grid">
          <AgentCard 
            theme="orange"
            iconSvg={<SearchIcon />}
            title="1. ETL DISCOVERY AGENT"
            subtitle="Discover & Inventory ETL Assets"
            description="Discover pipelines, jobs, mappings, schedules and metadata across your ETL ecosystem."
          />
          <AgentCard 
            theme="orange"
            iconSvg={<NetworkIcon />}
            title="2. ETL INTELLIGENCE AGENT"
            subtitle="Extract Lineage & Understand"
            description="Extract end-to-end data lineage, transformations, business rules and technical metadata."
            subAgents={etlIntelligenceSubAgents}
          />
          <AgentCard 
            theme="orange"
            iconSvg={<ClipboardIcon />}
            title="3. ETL RATIONALISATION AGENT"
            subtitle="Analyze, Assess & Recommend"
            description="Identify redundant pipelines, assess complexity and recommend keep, consolidate, or retire."
          />
          <AgentCard 
            theme="orange"
            iconSvg={<DatabaseIcon />}
            title="4. ETL MIGRATION AGENT"
            subtitle="Migrate & Validate with Confidence"
            description="Perform source validation, impact analysis, mapping and migrate pipelines to target platforms."
            subAgents={etlMigrationSubAgents}
          />
        </div>
        <div className="section-footer">
          <a href="#" className="btn-primary blue">
            Get Started &rarr;
          </a>
        </div>
      </div>
    </div>
    </>
  );
}

export default App;
